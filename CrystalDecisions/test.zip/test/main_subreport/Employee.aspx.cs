﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace test.main_subreport
{
    public partial class Employee : System.Web.UI.Page
    {
        ReportDocument rpt = new ReportDocument();
        string connectionString = "Data Source=DESKTOP-GSHNUAF\\SQLEXPRESS;Initial Catalog=TEST;Integrated Security=True";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) { 
                LoadReport();
            }
        }

        private void LoadReport()
        {
            string mainPath = Server.MapPath("rptDepartmentMain.rpt");
            rpt.Load(mainPath);

            DataTable dtMain = GetDataTable("SELECT * FROM C_Department");
            rpt.SetDataSource(dtMain);

            DataTable dtSub = GetDataTable("SELECT * FROM C_Empdetails");
            rpt.Subreports["rptEmployeeSub.rpt"].SetDataSource(dtSub);

            rpt.PrintOptions.PaperSize = CrystalDecisions.Shared.PaperSize.PaperA4;
            rpt.PrintOptions.PaperOrientation = CrystalDecisions.Shared.PaperOrientation.Landscape;

            rpt.ExportToHttpResponse(ExportFormatType.PortableDocFormat, Response, false, "DepartmentReport");
        }




        private DataTable GetDataTable(string query)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlDataAdapter da = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        protected void Page_Unload(object sender, EventArgs e)
        {
            rpt.Close();
            rpt.Dispose();
        }
    }
}